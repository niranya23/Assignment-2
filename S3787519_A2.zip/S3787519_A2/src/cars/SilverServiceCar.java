package cars;

import utilities.DateTime;
import utilities.DateUtilities;

public class SilverServiceCar extends Car {
	private double bookingFee;
	private String[] refreshments;

	public SilverServiceCar(String regNo, String make, String model, String driverName, int passengerCapacity,
			double bookingFee, String[] refreshments) {
		super(regNo, make, model, driverName, passengerCapacity);
		this.bookingFee = bookingFee;
		this.refreshments = refreshments;
	}

	@Override
	public double getBookingFee() {
		return bookingFee;
	}

	public String[] getRefreshments() {
		return refreshments;
	}

	@Override
	protected boolean dateIsValid(DateTime date) {
		return DateUtilities.deteIsNotMoreThan3Days(date);
	}

	@Override
	public String getDetails() {
		StringBuffer buff = new StringBuffer();
		buff.append(super.getDetails());
		Booking[] currentBookings = getCurrentBookings();
		Booking[] pastBookings = getPastBookings();
		if (null != refreshments) {
			buff.append("Refreshments Available\n");
			for (int i = 0; i < refreshments.length; i++) {
				buff.append("Item").append(i + 1).append("  ").append(refreshments[i]).append("\n");
			}
		}
		if (null != currentBookings) {
			for (int i = 0; i < currentBookings.length; i++) {
				Booking b = currentBookings[i];
				if (null == b)
					break;
				if (i == 0)
					buff.append("Current Booking\n");
				buff.append(getRecordMarker()).append("\n").append(b.getDetails());
			}
		}
		if (null != pastBookings) {
			for (int i = 0; i < pastBookings.length; i++) {
				Booking b = pastBookings[i];
				if (null == b)
					break;
				if (i == 0)
					buff.append("Past Booking\n");
				buff.append(getRecordMarker()).append("\n").append(b.getDetails());
			}
		}
		return buff.toString();
	}

	@Override
	protected String getCarDetailsFlat() {
		StringBuffer buff = new StringBuffer();
		buff.append(super.getCarDetailsFlat());
		if (null != refreshments) {
			buff.append("|");
			for (int i = 0; i < refreshments.length; i++) {
				buff.append("Item").append(i + 1).append("  ").append(refreshments[i]);
			}
		}
		return buff.toString();
	}

	@Override
	protected double calculateTripFee(double kilometers) {
		return kilometers * (getBookingFee() * .4);
	}
}
