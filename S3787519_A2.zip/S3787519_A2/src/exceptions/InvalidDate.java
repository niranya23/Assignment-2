package exceptions;

@SuppressWarnings("serial")
public class InvalidDate extends Exception {

	public InvalidDate(String message) {
		super(message);
	}

}
