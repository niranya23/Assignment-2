package exceptions;

public class InvalidBooking {

}
