package utilities;

public class MiRidesUtilities {

	private static final String[] AVAIPABLE_SERVICE_TYPE = new String[] { "SD", "SS" };
	private final static int ID_LENGTH = 6;
	private final static double MINIMUM_STANDARD_FEE = 3;

	public static String isRegNoValid(String regNo) {
		int regNoLength = regNo.length();
		if (regNoLength != ID_LENGTH) {
			return "Error: registration number must be 6 characters";
		}
		boolean letters = regNo.substring(0, 3).matches("[a-zA-Z]+");
		if (!letters) {
			return "Error: The registration number should begin with three alphabetical characters.";
		}
		boolean numbers = regNo.substring(3).matches("[0-9]+");
		if (!numbers) {
			return "Error: The registration number should end with three numeric characters.";
		}
		return regNo;
	}

	public static String isPassengerCapacityValid(int passengerCapacity) {
		if (passengerCapacity > 0 && passengerCapacity < 10) {
			return "OK";
		} else {
			return "Error: Passenger capacity must be between 1 and 9.";
		}
	}

	public static String isStandardFeeValid(double standardFee) {
		if (standardFee >= MINIMUM_STANDARD_FEE) {
			return "OK";
		} else {
			return "Error: Standard fee must be atleast $3.0";
		}
	}

	public static String isServiceTypeValid(String serviceType) {
		for (String t : AVAIPABLE_SERVICE_TYPE) {
			if (t.equals(serviceType))
				return "OK";
		}
		return "Error: Service Type must be one of " + String.valueOf(AVAIPABLE_SERVICE_TYPE);
	}

	public static String isRefreshmentsValid(String line) {
		if (null == line || "".equals(line)) {
			return "Error: No refreshments found";
		}
		String[] refreshments = line.split(",");
		if (null == refreshments || refreshments.length < 3) {
			return "Error: Add atleast 3 refreshments";
		}
		for (String r : refreshments) {
			if (null == r || "".equals(r)) {
				return "Error: Invalid refreshment";
			}
		}
		return "Ok";
	}
}
