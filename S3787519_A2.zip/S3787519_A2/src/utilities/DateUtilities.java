package utilities;

import exceptions.InvalidDate;

public class DateUtilities {
	public static boolean dateIsNotInPast(DateTime date) {
		@SuppressWarnings("unused")
		final int OFFSET_FOR_DAYS_IN_MILLISECONDS = 1;
		boolean notInPast = false;

		DateTime today = new DateTime();

		int daysInPast = DateTime.diffDays(date, today);
		if (daysInPast >= 0) {
			notInPast = true;
		}

		return notInPast;
	}

	public static boolean datesAreTheSame(DateTime date1, DateTime date2) {
		if (date1.getEightDigitDate().equals(date2.getEightDigitDate())) {
			return true;
		}
		return false;
	}

	public static boolean dateIsNotMoreThan7Days(DateTime date) {
		boolean within7Days = false;
		DateTime today = new DateTime();
		int daysInFuture = DateTime.diffDays(date, today);
		if (daysInFuture >= 0 && daysInFuture < 8) {
			within7Days = true;
		}
		return within7Days;
	}

	public static boolean deteIsNotMoreThan3Days(DateTime date) {
		boolean within3Days = false;
		DateTime today = new DateTime();
		int daysInFuture = DateTime.diffDays(date, today);
		if (daysInFuture >= 0 && daysInFuture < 4) {
			within3Days = true;
		}
		return within3Days;
	}

	public static DateTime parseDDMMYYY(String date) throws InvalidDate {
		try {
			int day = Integer.parseInt(date.substring(0, 2));
			int month = Integer.parseInt(date.substring(3, 5));
			int year = Integer.parseInt(date.substring(6));
			return new DateTime(day, month, year);
		} catch (Exception e) {
			throw new InvalidDate("unnable to create DateTime object from the give date string");
		}
	}
}
