package utilities;

public class List<I> {

	private static final int INCREASE_FACTOR = 10;

	private Object[] mItems;
	private int mSize = 0;
	private int mIncreaseFactor = INCREASE_FACTOR;
	private int mCapacity = mIncreaseFactor;
	private int mNextInsertPosition = -1;

	public List() {
		this(INCREASE_FACTOR);
	}

	public List(int initialSize) {
		if (initialSize <= 0)
			throw new IllegalArgumentException("initial size must be minimum 1");
		mIncreaseFactor = initialSize;
		mCapacity = mIncreaseFactor;
		mNextInsertPosition = 0;
	}

	public void add(@SuppressWarnings("unchecked") I... items) {
		if (items == null)
			return;
		for (I item : items) {
			createOrIncreaseSize();
			mItems[mNextInsertPosition] = item;
			mNextInsertPosition++;
			mSize++;
		}
	}

	@SuppressWarnings("unchecked")
	public I get(int index) {
		if (!isValidIdex(index))
			return null;
		return (I) mItems[index];
	}

	@SuppressWarnings("unchecked")
	public I remove(int index) {
		if (!isValidIdex(index))
			return null;
		Object removedItem = mItems[index];
		Object[] tmp = new Object[mCapacity];
		System.arraycopy(mItems, 0, tmp, 0, index);
		if (index != mSize - 1) {
			System.arraycopy(mItems, index + 1, tmp, index + 1, mSize - index - 1);
		}
		mNextInsertPosition--;
		return (I) removedItem;
	}

	public int size() {
		return mSize;
	}

	public void clear() {
		for (int i = 0; i < mSize; i++) {
			mItems[i] = null;
		}
		mItems = null;
		mSize = 0;
		mNextInsertPosition = 0;
	}

	private void createOrIncreaseSize() {
		if (mItems == null) {
			mItems = new Object[mIncreaseFactor];
			return;
		}
		if (mSize < mCapacity)
			return;

		mCapacity += mIncreaseFactor;
		Object[] newItems = new Object[mCapacity];
		System.arraycopy(mItems, 0, newItems, 0, mSize);
		mItems = newItems;
	}

	private boolean isValidIdex(int index) {
		return index >= 0 && index < mSize;
	}

}
