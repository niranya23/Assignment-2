package app;

import cars.Car;
import cars.SilverServiceCar;
import utilities.DateTime;
import utilities.MiRidesUtilities;

import java.io.*;
import java.util.Scanner;

/*
 * Class:			MiRideApplication
 * Description:		The system manager the manages the 
 *              	collection of data. 
 * Author:			Rodney Cocker
 */
@SuppressWarnings("unused")
public class MiRideApplication {
	private File DIRECTORY = new File("E:\\");
	private Car[] cars = new Car[15];
	private int itemCount = 0;
	private String[] availableCars;

	public MiRideApplication() {
		// seedData();
	}

	public String createCar(String id, String make, String model, String driverName, int numPassengers,
			String serviceType, double standardFee, String[] refreshments) {
		String validId = isValidId(id);
		if (isValidId(id).contains("Error:")) {
			return validId;
		}
		if (!checkIfCarExists(id)) {
			if ("SD".equals(serviceType)) {
				cars[itemCount] = new Car(id, make, model, driverName, numPassengers);
			} else if ("SS".equals(serviceType)) {
				cars[itemCount] = new SilverServiceCar(id, make, model, driverName, numPassengers, standardFee,
						refreshments);
			}
			itemCount++;
			return "New Car added successfully for registion number: " + cars[itemCount - 1].getRegistrationNumber();
		}
		return "Error: Already exists in the system.";
	}

	public String[] book(DateTime dateRequired) {
		return book(dateRequired, "SD");
	}

	public String[] book(DateTime dateRequired, String type) {
		int numberOfAvailableCars = 0;
		// finds number of available cars to determine the size of the array required.
		for (int i = 0; i < cars.length; i++) {
			Car c = cars[i];
			if (c != null) {
				if (!c.isCarBookedOnDate(dateRequired)) {
					if ("SS".equals(type) && (c.getClass() == SilverServiceCar.class)) {
						numberOfAvailableCars++;
					} else if ("SD".equals(type) && (c.getClass() != SilverServiceCar.class)) {
						numberOfAvailableCars++;
					}
				}
			}
		}
		if (numberOfAvailableCars == 0) {
			String[] result = new String[0];
			return result;
		}
		availableCars = new String[numberOfAvailableCars];
		int availableCarsIndex = 0;
		// Populate available cars with registration numbers
		for (int i = 0; i < cars.length; i++) {
			Car c = cars[i];
			if (c != null) {
				if (!c.isCarBookedOnDate(dateRequired)) {
					if ("SS".equals(type) && (c.getClass() == SilverServiceCar.class)) {
						availableCars[availableCarsIndex] = availableCarsIndex + 1 + ". "
								+ cars[i].getRegistrationNumber();
						availableCarsIndex++;
					} else if ("SD".equals(type) && (c.getClass() != SilverServiceCar.class)) {
						availableCars[availableCarsIndex] = availableCarsIndex + 1 + ". "
								+ cars[i].getRegistrationNumber();
						availableCarsIndex++;
					}
				}
			}
		}
		return availableCars;
	}

	public String book(String firstName, String lastName, DateTime required, int numPassengers,
			String registrationNumber) {
		Car car = getCarById(registrationNumber);
		if (car != null) {
			if (car.book(firstName, lastName, required, numPassengers)) {

				String message = "Thank you for your booking. \n" + car.getDriverName() + " will pick you up on "
						+ required.getFormattedDate() + ". \n" + "Your booking reference is: "
						+ car.getBookingID(firstName, lastName, required);
				return message;
			} else {
				String message = "Booking could not be completed.";
				return message;
			}
		} else {
			return "Car with registration number: " + registrationNumber + " was not found.";
		}
	}

	public String completeBooking(String firstName, String lastName, DateTime dateOfBooking, double kilometers) {
		String result = "";

		// Search all cars for bookings on a particular date.
		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				if (cars[i].isCarBookedOnDate(dateOfBooking)) {
					return cars[i].completeBooking(firstName, lastName, dateOfBooking, kilometers);
				}
//				else
//				{
//					
//				}
//				if(!result.equals("Booking not found"))
//				{
//					return result;
//				}
			}
		}
		return "Booking not found.";
	}

	public String completeBooking(String firstName, String lastName, String registrationNumber, double kilometers) {
		String carNotFound = "Car not found";
		Car car = null;
		// Search for car with registration number
		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				if (cars[i].getRegistrationNumber().equals(registrationNumber)) {
					car = cars[i];
					break;
				}
			}
		}

		if (car == null) {
			return carNotFound;
		}
		if (car.getBookingByName(firstName, lastName) != -1) {
			return car.completeBooking(firstName, lastName, kilometers);
		}
		return "Error: Booking not found.";
	}

	public boolean getBookingByName(String firstName, String lastName, String registrationNumber) {
		String bookingNotFound = "Error: Booking not found";
		Car car = null;
		// Search for car with registration number
		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				if (cars[i].getRegistrationNumber().equals(registrationNumber)) {
					car = cars[i];
					break;
				}
			}
		}

		if (car == null) {
			return false;
		}
		if (car.getBookingByName(firstName, lastName) == -1) {
			return false;
		}
		return true;
	}

	public String displaySpecificCar(String regNo) {
		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				if (cars[i].getRegistrationNumber().equals(regNo)) {
					return cars[i].getDetails();
				}
			}
		}
		return "Error: The car could not be located.";
	}

	public boolean seedData() {
		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				return false;
			}
		}
		// 2 cars not booked
		Car honda = new Car("SIM194", "Honda", "Accord Euro", "Henry Cavill", 5);
		cars[itemCount] = honda;
		honda.book("Craig", "Cocker", new DateTime(1), 3);
		itemCount++;

		Car lexus = new Car("LEX666", "Lexus", "M1", "Angela Landsbury", 3);
		cars[itemCount] = lexus;
		lexus.book("Craig", "Cocker", new DateTime(1), 3);
		itemCount++;

		// 2 cars booked
		Car bmw = new Car("BMW256", "Mini", "Minor", "Barbara Streisand", 4);
		cars[itemCount] = bmw;
		itemCount++;
		bmw.book("Craig", "Cocker", new DateTime(1), 3);

		Car audi = new Car("AUD765", "Mazda", "RX7", "Matt Bomer", 6);
		cars[itemCount] = audi;
		itemCount++;
		audi.book("Rodney", "Cocker", new DateTime(1), 4);

		// 1 car booked five times (not available)
		Car toyota = new Car("TOY765", "Toyota", "Corola", "Tina Turner", 7);
		cars[itemCount] = toyota;
		itemCount++;
		toyota.book("Rodney", "Cocker", new DateTime(1), 3);
		toyota.book("Craig", "Cocker", new DateTime(2), 7);
		toyota.book("Alan", "Smith", new DateTime(3), 3);
		toyota.book("Carmel", "Brownbill", new DateTime(4), 7);
		toyota.book("Paul", "Scarlett", new DateTime(5), 7);
		toyota.book("Paul", "Scarlett", new DateTime(6), 7);
		toyota.book("Paul", "Scarlett", new DateTime(7), 7);

		// 1 car booked five times (not available)
		Car rover = new Car("ROV465", "Honda", "Rover", "Jonathon Ryss Meyers", 7);
		cars[itemCount] = rover;
		itemCount++;
		rover.book("Rodney", "Cocker", new DateTime(1), 3);
		// rover.completeBooking("Rodney", "Cocker", 75);
		DateTime inTwoDays = new DateTime(2);
		rover.book("Rodney", "Cocker", inTwoDays, 3);
		rover.completeBooking("Rodney", "Cocker", inTwoDays, 75);

		// 2 silverservice cars not booked
		Car roverSS = new SilverServiceCar("ROV263", "Honda", "Rover", "Jonathon Ryss Meyers", 7, 3.4,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		cars[itemCount++] = roverSS;
		Car toyotaSS = new SilverServiceCar("TOY845", "Toyota", "Corola", "Tina Turner", 7, 4,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		cars[itemCount++] = toyotaSS;

		// 2 silverservice cars booked but booking not complete
		Car bmwSS = new SilverServiceCar("BMW906", "Mini", "Minor", "Barbara Streisand", 4, 5,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		bmwSS.book("Craig", "Cocker", new DateTime(1), 3);
		cars[itemCount++] = bmwSS;

		Car hondaSS = new SilverServiceCar("SIM132", "Honda", "Accord Euro", "Henry Cavill", 5, 4.5,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		hondaSS.book("Craig", "Cocker", new DateTime(1), 3);
		cars[itemCount++] = hondaSS;

		// 2 silverservice cars booked and booking completed
		Car audiSS = new SilverServiceCar("AUD711", "Mazda", "RX7", "Matt Bomer", 6, 5,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		audiSS.book("Rodney", "Muller", new DateTime(1), 4);
		audiSS.completeBooking("Rodney", "Muller", new DateTime(1), 5);
		cars[itemCount++] = audiSS;

		Car lexusSS = new SilverServiceCar("LEX699", "Lexus", "M1", "Angela Landsbury", 3, 4,
				new String[] { "Mint", "Orange Juice", "Chocolate Bar" });
		lexusSS.book("Craig", "Ray", new DateTime(2), 3);
		lexusSS.completeBooking("Craig", "Ray", new DateTime(2), 2);
		cars[itemCount++] = lexusSS;

		return true;
	}

	public String displayAllBookings() {
		if (itemCount == 0) {
			return "No cars have been added to the system.";
		}
		StringBuilder sb = new StringBuilder();
		sb.append("Summary of all cars: ");
		sb.append("\n");

		for (int i = 0; i < itemCount; i++) {
			sb.append(cars[i].getDetails());
		}
		return sb.toString();
	}

	public String displayAllBookings(String type, String order) {
		if (itemCount == 0) {
			return "No cars have been added to the system.";
		}
		Car[] tmp = sortByBookingFee(cars, itemCount, "A".equals(order));
		;
		StringBuilder sb = new StringBuilder();
		sb.append("Summary of all cars: ");
		sb.append("\n");
		for (int i = 0; i < itemCount; i++) {
			// System.out.println("SS".equals(type) && tmp[i].getClass() ==
			// SilverServiceCar.class);
			if ("SS".equals(type)) {
				if (tmp[i].getClass() == SilverServiceCar.class)
					sb.append(tmp[i].getDetails());
			} else if ("SD".equals(type)) {
				if (tmp[i].getClass() != SilverServiceCar.class)
					sb.append(tmp[i].getDetails());
			}
		}
		return sb.toString();
	}

	private Car[] sortByBookingFee(Car[] toSort, int size, boolean asc) {
		for (int i = 0; i < size - 1; i++) {
			for (int j = i + 1; j < size; j++) {
				if (asc && toSort[i].getBookingFee() > toSort[j].getBookingFee()) {
					Car tmp = toSort[i];
					toSort[i] = toSort[j];
					toSort[j] = tmp;
				} else if (!asc && toSort[i].getBookingFee() < toSort[j].getBookingFee()) {
					Car tmp = toSort[i];
					toSort[i] = toSort[j];
					toSort[j] = tmp;
				}
			}
		}
		return toSort;
	}

	public String displayBooking(String id, String seatId) {
		Car booking = getCarById(id);
		if (booking == null) {
			return "Booking not found";
		}
		return booking.getDetails();
	}

	public String isValidId(String id) {
		return MiRidesUtilities.isRegNoValid(id);
	}

	public String isValidPassengerCapacity(int passengerNumber) {
		return MiRidesUtilities.isPassengerCapacityValid(passengerNumber);
	}

	public String isValidStandardFee(double standardFee) {
		return MiRidesUtilities.isStandardFeeValid(standardFee);
	}

	public String isValidServiceType(String serviceType) {
		return MiRidesUtilities.isServiceTypeValid(serviceType);
	}

	public String isValidRefreshments(String line) {
		return MiRidesUtilities.isRefreshmentsValid(line);
	}

	public boolean checkIfCarExists(String regNo) {
		Car car = null;
		if (regNo.length() != 6) {
			return false;
		}
		car = getCarById(regNo);
		if (car == null) {
			return false;
		} else {
			return true;
		}
	}

	private Car getCarById(String regNo) {
		Car car = null;

		for (int i = 0; i < cars.length; i++) {
			if (cars[i] != null) {
				if (cars[i].getRegistrationNumber().equals(regNo)) {
					car = cars[i];
					return car;
				}
			}
		}
		return car;
	}

	public void restoreFromFile() {
		try {
			File dataFile = new File(DIRECTORY, "MiRides.txt");
			if (!dataFile.exists()) {
				dataFile = new File(DIRECTORY, "MiRidesBackup.txt");
				if (!dataFile.exists()) {
					System.out.println("no file found to restore");
					return;
				}
			}
			BufferedReader reader = new BufferedReader(new FileReader(dataFile));
			String line = null;
			while ((line = reader.readLine()) != null) {
				String[] parts = line.split(":");
				String type = parts[0];
				String regNo = parts[1];
				String make = parts[2];
				String model = parts[3];
				String driverName = parts[4];
				int passengercapacity = Integer.parseInt(parts[5]);
				if ("SS".equals(parts[0])) {
					double bookingFee = Double.parseDouble(parts[5]);
					String[] refreshments = parts[6].split(",");
					createCar(regNo, make, model, driverName, passengercapacity, type, bookingFee, refreshments);
				} else if ("SD".equals(parts[0])) {
					createCar(regNo, make, model, driverName, passengercapacity, type, 0, null);
				}
			}
			reader.close();
		} catch (IOException e) {
			System.out.println("Error: " + e.getMessage());
		}
	}

	public void saveToFile() {
		try {
			PrintWriter writerMain = new PrintWriter(new FileOutputStream(new File(DIRECTORY, "MiRides.txt")));
			PrintWriter writerBackup = new PrintWriter(new FileOutputStream(new File(DIRECTORY, "MiRidesBackup.txt")));
			for (Car c : cars) {
				if (c == null)
					break;
				String serialize = serializeCar(c);
				writerMain.write(serialize);
				writerMain.write("\r\n");
				writerBackup.write(serialize);
				writerBackup.write("\r\n");
			}
			writerMain.flush();
			writerMain.close();
			writerBackup.flush();
			writerBackup.close();
		} catch (IOException e) {
		}
	}

	private String serializeCar(Car c) {
		StringBuffer sb = new StringBuffer();
		if (c instanceof SilverServiceCar) {
			sb.append("SS:");
		} else {
			sb.append("SD:");
		}
		sb.append(c.getRegistrationNumber()).append(":").append(c.getMake()).append(":").append(c.getModel())
				.append(":").append(c.getDriverName()).append(":").append(c.getPassengerCapacity());
		if (c.getClass() == SilverServiceCar.class) {
			sb.append(":").append(c.getBookingFee()).append(":");
			String[] refreshments = ((SilverServiceCar) c).getRefreshments();
			for (int i = 0; i < refreshments.length; i++) {
				sb.append(refreshments[i]);
				if (i < refreshments.length - 1) {
					sb.append(",");
				}
			}
		}
		return sb.toString();
	}
}
